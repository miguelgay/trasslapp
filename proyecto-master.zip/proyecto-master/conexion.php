<?php
    $con=mysqli_connect("localhost","root","","proyecto2305") or die("error en conexion");
?>