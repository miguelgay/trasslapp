
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

.card {
    height: 500px;
    margin-right:600px;
}

.carrusel {
    margin-top: 100px;
    margin-left: 500px;
    height: 30%;
    width: 50%;
}



body {
    background: #dadada;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: "Bebas Neue", sans-serif;
    font-weight: 400;
    font-size: 16px;
    background-color: #EBEBEB;
}
</style>

<body>

    <br><br>
    <div class="container">
        <section class="cards">
            <div class="card" style="width: 18rem; height:525px; margin: left 40%;">
                <img src="../img/reserva-hotel.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h4 class="card-title text-center">
                       <strong>Reservas</strong> 
                    </h4>
                    <h5 class="card-title"> Encuentra aqui la información de tus reservas</h5>
                    <p class="card-text"> Modifca o eliminalas a tus necesidades</p>
                    <p></p>
                    <a href="dashboard.php?mod=reserva" class="btn btn-primary btn_hotels">Gestiona tus reservas</a>
                </div>
                <h2 style="">Conoce los hoteles:</h2>
<div class="container">
        <section class="cards">
            <div class="card" style="width: 18rem; height:525px;">
                <img src="../img/hotel4.webp" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">ibis budget Itagui</h5>
                    <p class="card-text"> Calle 50 # 40 -17, 55413 Medellín, Colombia</p>
                    <p>Precios a partir de COP: 160.000</p>
                    <a href="https://acortar.link/nvXxqH" class="btn btn-primary btn_reservar">Reservar hotel</a>
                </div>
                
        </section>
    </div>

</body>

</html>